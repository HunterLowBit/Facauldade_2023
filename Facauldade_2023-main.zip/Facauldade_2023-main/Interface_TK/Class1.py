class Humano:
    def __init__(self, nome, cor, roupa, vida):
        self.nome = nome
        self.cor = cor
        self.roupa = roupa
        self.vida = vida
        self.__VidaCalculo = 0
        self.__VidaReduz = 0

def atacar(self):
    self.VidaCalculo +=1

def reduzVida(self):
    self.__VidaReduz = self.__VidaCalculo - self.vida    
