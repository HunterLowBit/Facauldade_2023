i = int(input("Digite numero inicial: " ))
a = int(input("até que numero deseja exibir? "))
while i < a:
  print(i)
  i += 1
else:
  print("por ultimo, {}".format(a))