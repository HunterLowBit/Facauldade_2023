Quantidade = int(input(" Digite até que numero deseja exibir: "))
for Numero in range(Quantidade + 1):
  print(Numero)