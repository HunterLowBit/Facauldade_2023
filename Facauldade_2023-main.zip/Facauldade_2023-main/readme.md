# Facauldade_2023

Repositório de testes e atividades, Atualizado de acordo com as aulas para receber e 
compartilhar arquivos no qual ando treinando. Objetivo principal é documentar e guardar
progressos conforme o necessário para futuramente revisitar tudo.
