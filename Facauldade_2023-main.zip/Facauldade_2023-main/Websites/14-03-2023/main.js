function criaPessoa(nome, sobrenome){
    return{
        nome: nome, sobrenome: sobrenome
    }; 
}

const p1 = criaPessoa('Fabricio', 'Dias');