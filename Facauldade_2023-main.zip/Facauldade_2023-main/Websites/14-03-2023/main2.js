document.addEventListener('click',()=>{
    document.body.style.backgroundColor = 'black';
});

//pesquisar don
//pesquisar sobre os addEventListener
//Foco Principal em como funciona a manipulação pelo document
//criar codigo exemplo addevent
//a document

//Até segunda